$ErrorActionPreference = "Stop"
$GradleVersion = "9.3.1"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Cache = Join-Path $Root ".local-gradle"
$Zip = Join-Path $Cache "gradle-$GradleVersion-bin.zip"
$Home = Join-Path $Cache "gradle-$GradleVersion"
New-Item -ItemType Directory -Force -Path $Cache | Out-Null
if (!(Test-Path $Home)) {
  Write-Host "Downloading Gradle $GradleVersion..."
  Invoke-WebRequest "https://services.gradle.org/distributions/gradle-$GradleVersion-bin.zip" -OutFile $Zip
  Expand-Archive -Force $Zip $Cache
}
$gradle = Join-Path $Home "bin\gradle.bat"
Push-Location $Root
& $gradle :app:assembleDebug
Pop-Location
$apk = Join-Path $Root "app\build\outputs\apk\debug\app-debug.apk"
if (Test-Path $apk) { Write-Host "APK: $apk" } else { throw "APK not found" }
