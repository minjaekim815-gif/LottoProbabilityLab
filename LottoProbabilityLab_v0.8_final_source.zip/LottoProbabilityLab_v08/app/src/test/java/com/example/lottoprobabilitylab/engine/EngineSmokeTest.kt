package com.example.lottoprobabilitylab.engine

import com.example.lottoprobabilitylab.model.LottoDraw
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EngineSmokeTest {
    @Test fun scoreRangeIsValid() {
        val draws = (1..150).map { round ->
            val base = ((round * 7) % 45) + 1
            val nums = generateSequence(base) { (it % 45) + 1 }.take(7).toList()
            LottoDraw(round, nums.take(6), nums[6])
        }
        val result = LottoAnalysisEngine().analyze(draws)
        assertEquals(45, result.numberRanking.size)
        assertTrue(result.numberRanking.all { it.second in 0.0..1.0 })
        assertEquals(10, result.combinations.size)
    }
}
