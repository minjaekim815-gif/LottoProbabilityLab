package com.example.lottoprobabilitylab.engine

import com.example.lottoprobabilitylab.model.LottoDraw
import kotlin.math.sqrt

data class HoldoutValidationSummary(
    val holdoutRounds: Int,
    val trainRounds: Int,
    val averageHitsTop10: Double,
    val averageHitsTop15: Double,
    val averageHitsTop20: Double,
    val expectedTop10: Double,
    val expectedTop15: Double,
    val expectedTop20: Double,
    val zTop10: Double,
    val zTop15: Double,
    val zTop20: Double,
    val verdict: String
)

/**
 * 최종 과적합 점검용 고정 holdout 검증.
 * 마지막 N개 회차는 가중치 학습에 전혀 사용하지 않고, 그 이전 구간에서 확정한 가중치를
 * holdout 전체에 고정한 채 평가한다. Walk-forward와 별도로 "튜닝 후 미사용 구간" 성능을 본다.
 */
class FinalValidationEngine(
    private val scorer: NumberScorer = NumberScorer(),
    private val backtestEngine: BacktestEngine = BacktestEngine(),
    private val holdoutSize: Int = 60,
    private val minTrain: Int = 300
) {
    fun run(draws: List<LottoDraw>): HoldoutValidationSummary {
        val sorted = draws.sortedBy { it.round }
        if (sorted.size < minTrain + 20) return neutral(sorted.size)
        val h = holdoutSize.coerceAtMost(sorted.size - minTrain).coerceAtLeast(20)
        val split = sorted.size - h
        val train = sorted.subList(0, split)
        val trainBacktest = backtestEngine.run(train)
        val fixedWeights = trainBacktest.performances.associate { it.technique to it.weight }

        val hits10 = mutableListOf<Int>()
        val hits15 = mutableListOf<Int>()
        val hits20 = mutableListOf<Int>()
        for (targetIndex in split until sorted.size) {
            val history = sorted.subList(0, targetIndex)
            val actual = sorted[targetIndex].allSeven.toSet()
            val techniqueScores = scorer.score(history)
            val aggregate = (1..45).associateWith { n ->
                techniqueScores.entries.sumOf { (t, m) -> m.getValue(n) * (fixedWeights[t] ?: 0.0) }
            }
            val ranked = aggregate.entries.sortedByDescending { it.value }.map { it.key }
            hits10 += ranked.take(10).count { it in actual }
            hits15 += ranked.take(15).count { it in actual }
            hits20 += ranked.take(20).count { it in actual }
        }

        val n = hits10.size
        val a10 = hits10.average(); val a15 = hits15.average(); val a20 = hits20.average()
        val e10 = 7.0 * 10 / 45.0; val e15 = 7.0 * 15 / 45.0; val e20 = 7.0 * 20 / 45.0
        val z10 = z(a10, 10, n); val z15 = z(a15, 15, n); val z20 = z(a20, 20, n)
        val verdict = when {
            z15 >= 1.96 && z20 >= 1.0 -> "holdout에서도 우위 신호"
            z15 >= 1.0 || z20 >= 1.0 -> "약한 우위 신호"
            z15 <= -1.96 || z20 <= -1.96 -> "holdout 성능 저조"
            else -> "무작위 대비 뚜렷한 우위 없음"
        }
        return HoldoutValidationSummary(h, train.size, a10, a15, a20, e10, e15, e20, z10, z15, z20, verdict)
    }

    private fun z(mean: Double, k: Int, rounds: Int): Double {
        if (rounds <= 0) return 0.0
        val p = 7.0 / 45.0
        val varianceOne = k * p * (1.0 - p) * ((45.0 - k) / 44.0)
        val se = sqrt(varianceOne / rounds).coerceAtLeast(1e-9)
        return (mean - 7.0 * k / 45.0) / se
    }

    private fun neutral(size: Int) = HoldoutValidationSummary(
        holdoutRounds = 0, trainRounds = size,
        averageHitsTop10 = 0.0, averageHitsTop15 = 0.0, averageHitsTop20 = 0.0,
        expectedTop10 = 7.0*10/45.0, expectedTop15 = 7.0*15/45.0, expectedTop20 = 7.0*20/45.0,
        zTop10 = 0.0, zTop15 = 0.0, zTop20 = 0.0,
        verdict = "검증 데이터 부족"
    )
}
