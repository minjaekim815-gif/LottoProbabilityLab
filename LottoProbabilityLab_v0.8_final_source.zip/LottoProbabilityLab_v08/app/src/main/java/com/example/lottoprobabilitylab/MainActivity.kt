package com.example.lottoprobabilitylab

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.lottoprobabilitylab.data.LottoRepository
import com.example.lottoprobabilitylab.engine.AnalysisResult
import com.example.lottoprobabilitylab.engine.CombinationCandidate
import com.example.lottoprobabilitylab.engine.LottoAnalysisEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { LottoApp() } }
    }
}

private enum class Screen(val label: String, val iconText: String) {
    HOME("추천", "◎"),
    ANALYSIS("분석", "#"),
    BACKTEST("검증", "▥"),
    WEIGHTS("가중치", "Σ")
}

@Composable
fun LottoApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val repo = remember { LottoRepository(context) }
    var screen by remember { mutableStateOf(Screen.HOME) }
    var result by remember { mutableStateOf<AnalysisResult?>(null) }
    var latestRound by remember { mutableStateOf<Int?>(null) }
    var latestNumbers by remember { mutableStateOf<List<Int>>(emptyList()) }
    var latestBonus by remember { mutableStateOf<Int?>(null) }
    var sourceText by remember { mutableStateOf("") }
    var syncText by remember { mutableStateOf("") }
    var warning by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("데이터 준비 중") }
    var loading by remember { mutableStateOf(false) }

    fun run(refresh: Boolean) {
        if (loading) return
        loading = true
        status = if (refresh) "전체 회차 갱신 및 분석 중…" else "저장 데이터 분석 중…"
        scope.launch {
            try {
                val loaded = withContext(Dispatchers.IO) { repo.load(refresh) }
                val last = loaded.draws.last()
                latestRound = last.round
                latestNumbers = last.mainNumbers
                latestBonus = last.bonus
                sourceText = loaded.source
                warning = loaded.warning
                syncText = when {
                    !loaded.checkedOnline -> "온라인 확인 실패 · ${loaded.latestRound}회까지 저장 데이터 사용"
                    loaded.previousRound == null -> "1회~${loaded.latestRound}회 최초 저장 완료"
                    loaded.newRounds > 0 -> "새 회차 ${loaded.newRounds}개 반영 · ${loaded.previousRound}회 → ${loaded.latestRound}회"
                    else -> "최신 상태 확인 완료 · ${loaded.latestRound}회"
                }
                result = withContext(Dispatchers.Default) { LottoAnalysisEngine().analyze(loaded.draws) }
                status = if (loaded.newRounds > 0 && loaded.previousRound != null) {
                    "신규 실적 반영 및 ${loaded.latestRound + 1}회 전망 재계산 완료"
                } else {
                    "분석 완료 · ${loaded.draws.size}개 회차"
                }
            } catch (t: Throwable) {
                status = "오류: ${t.message ?: t.javaClass.simpleName}"
            } finally {
                loading = false
            }
        }
    }

    LaunchedEffect(Unit) { run(refresh = true) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("로또 확률 연구소", fontWeight = FontWeight.Bold)
                        result?.let { Text("${it.nextRound}회 전망 · v${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.labelMedium) }
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                Screen.entries.forEach { s ->
                    NavigationBarItem(
                        selected = screen == s,
                        onClick = { screen = s },
                        icon = { Text(s.iconText, fontWeight = FontWeight.Bold) },
                        label = { Text(s.label) }
                    )
                }
            }
        }
    ) { padding ->
        when (screen) {
            Screen.HOME -> HomeScreen(
                modifier = Modifier.padding(padding),
                result = result,
                latestRound = latestRound,
                latestNumbers = latestNumbers,
                latestBonus = latestBonus,
                status = status,
                source = sourceText,
                syncText = syncText,
                warning = warning,
                loading = loading,
                onRefresh = { run(true) },
                onOpenAnalysis = { screen = Screen.ANALYSIS }
            )
            Screen.ANALYSIS -> AnalysisScreen(Modifier.padding(padding), result)
            Screen.BACKTEST -> BacktestScreen(Modifier.padding(padding), result)
            Screen.WEIGHTS -> WeightsScreen(Modifier.padding(padding), result)
        }
    }
}

@Composable
private fun HomeScreen(
    modifier: Modifier,
    result: AnalysisResult?,
    latestRound: Int?,
    latestNumbers: List<Int>,
    latestBonus: Int?,
    status: String,
    source: String,
    syncText: String,
    warning: String?,
    loading: Boolean,
    onRefresh: () -> Unit,
    onOpenAnalysis: () -> Unit
) {
    LazyColumn(
        modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("과거 실적 기반 다음 회차 전망", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(
                "번호·조합 분석기법을 Walk-forward 방식으로 검증하고, 실제 과거 성적에 따라 가중치를 자동 조정합니다.",
                style = MaterialTheme.typography.bodyMedium
            )
        }
        item {
            StatusCard(status, source, syncText, warning, loading, onRefresh)
        }
        if (latestRound != null) {
            item {
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("최근 ${latestRound}회 결과", fontWeight = FontWeight.Bold)
                        NumberRow(latestNumbers, latestBonus)
                    }
                }
            }
        }
        result?.let { r ->
            item {
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("${r.nextRound}회 핵심 후보 7개", fontWeight = FontWeight.Bold)
                        NumberRow(r.outlookSeven)
                        Text(
                            "보너스 포함 7개 실적을 학습한 상위 후보군입니다. 아래 추천 10게임은 조합 백테스트 가중치를 별도로 적용합니다.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        OutlinedButton(onClick = onOpenAnalysis) { Text("번호별 분석 근거 보기") }
                    }
                }
            }
            item {
                Text("추천 10게임", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("점수가 높은 조합 중 서로 5개 이상 겹치는 조합은 최대한 피합니다.", style = MaterialTheme.typography.bodySmall)
            }
            items(r.combinations.zipWithIndex()) { (candidate, index) ->
                CombinationCard(index + 1, candidate)
            }
            item {
                Card {
                    Text(
                        "주의: 모든 정상적인 로또 6/45 조합의 이론적 1등 확률은 동일합니다. 이 앱의 점수는 과거 데이터에서 상대적으로 높은 평가를 받은 패턴을 정렬한 값이며 당첨을 보장하지 않습니다.",
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        } ?: item {
            Card { Text("분석이 끝나면 추천 번호가 표시됩니다.", Modifier.padding(16.dp)) }
        }
    }
}

@Composable
private fun StatusCard(
    status: String,
    source: String,
    syncText: String,
    warning: String?,
    loading: Boolean,
    onRefresh: () -> Unit
) {
    Card {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(status, fontWeight = FontWeight.Bold)
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            if (source.isNotBlank()) Text("데이터: $source", style = MaterialTheme.typography.bodySmall)
            if (syncText.isNotBlank()) Text(syncText, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
            warning?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
            Button(onClick = onRefresh, enabled = !loading) {
                Text(if (loading) "분석 중…" else "최신 회차 갱신")
            }
        }
    }
}

@Composable
private fun AnalysisScreen(modifier: Modifier, result: AnalysisResult?) {
    LazyColumn(
        modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("번호 분석", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("45개 번호의 종합 전망점수와 추천조합의 세부 평가를 확인합니다.")
        }
        if (result == null) {
            item { Text("분석을 먼저 실행하세요.") }
        } else {
            item {
                Text("${result.nextRound}회 번호 전망 순위", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
            items(result.numberRanking) { (n, score) ->
                Card {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        NumberBall(n)
                        Spacer(Modifier.width(12.dp))
                        LinearProgressIndicator(
                            progress = { score.toFloat().coerceIn(0f, 1f) },
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(Modifier.width(12.dp))
                        Text("%.1f".format(score * 100), fontWeight = FontWeight.Bold)
                    }
                }
            }
            item {
                Text("추천조합 세부 점수", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
            items(result.combinations.zipWithIndex()) { (candidate, index) ->
                DetailedCombinationCard(index + 1, candidate)
            }
        }
    }
}

@Composable
private fun CombinationCard(index: Int, c: CombinationCandidate) {
    Card {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("추천 $index", fontWeight = FontWeight.Bold)
                Text("종합 %.1f점".format(c.score * 100), fontWeight = FontWeight.Bold)
            }
            NumberRow(c.numbers)
            Text(
                "번호 %.1f · 합계 %.1f · Pair %.1f".format(c.numberScore * 100, c.sumFit * 100, c.pairFit * 100),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun DetailedCombinationCard(index: Int, c: CombinationCandidate) {
    Card {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("추천 $index · 종합 %.1f점".format(c.score * 100), fontWeight = FontWeight.Bold)
            NumberRow(c.numbers)
            MetricLine("번호 전망", c.numberScore)
            MetricLine("6개 합계", c.sumFit)
            MetricLine("홀짝 구성", c.oddEvenFit)
            MetricLine("구간 분포", c.rangeFit)
            MetricLine("연속번호", c.consecutiveFit)
            MetricLine("직전회차 중복", c.overlapFit)
            MetricLine("Pair/Lift", c.pairFit)
        }
    }
}

@Composable
private fun MetricLine(label: String, value: Double) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.width(104.dp), style = MaterialTheme.typography.bodySmall)
        LinearProgressIndicator(
            progress = { value.toFloat().coerceIn(0f, 1f) },
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(8.dp))
        Text("%.0f".format(value * 100), style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun BacktestScreen(modifier: Modifier, result: AnalysisResult?) {
    val b = result?.backtest
    LazyColumn(
        modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("과거 실적 검증", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("과거 회차의 정답을 가린 상태에서 당시까지의 데이터만 이용해 반복 검증합니다.")
        }
        if (b == null) {
            item { Text("분석을 먼저 실행하세요.") }
        } else {
            item {
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("번호 모델 · ${b.testedRounds}회 검증", fontWeight = FontWeight.Bold)
                        BacktestMetric("Top 10", b.averageHitsTop10, b.randomExpectedTop10, b.zTop10, b.evidenceLabel(b.zTop10))
                        BacktestMetric("Top 15", b.averageHitsTop15, b.randomExpectedTop15, b.zTop15, b.evidenceLabel(b.zTop15))
                        BacktestMetric("Top 20", b.averageHitsTop20, b.randomExpectedTop20, b.zTop20, b.evidenceLabel(b.zTop20))
                    }
                }
            }
            item {
                val h = result.holdoutValidation
                Text("최종 Holdout 검증", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("학습 ${h.trainRounds}회 · 미사용 검증 ${h.holdoutRounds}회", fontWeight = FontWeight.Bold)
                        Text(h.verdict, fontWeight = FontWeight.SemiBold)
                        BacktestMetric("Holdout Top 10", h.averageHitsTop10, h.expectedTop10, h.zTop10, "고정가중치")
                        BacktestMetric("Holdout Top 15", h.averageHitsTop15, h.expectedTop15, h.zTop15, "고정가중치")
                        BacktestMetric("Holdout Top 20", h.averageHitsTop20, h.expectedTop20, h.zTop20, "고정가중치")
                        Text("마지막 회차 구간은 가중치 학습에 사용하지 않고 별도로 검증합니다.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                val c = result.combinationBacktest
                Text("추천 10게임 조합 검증", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${c.testedRounds}회 · 회차당 ${c.ticketsPerRound}게임", fontWeight = FontWeight.Bold)
                        Text("회차별 최고 일치 평균: %.2f개 / 6".format(c.averageBestHits))
                        HorizontalDivider()
                        Text("최고 3개 이상 ${c.roundsBest3Plus}회")
                        Text("최고 4개 이상 ${c.roundsBest4Plus}회")
                        Text("최고 5개 이상 ${c.roundsBest5Plus}회")
                        Text("최고 6개 ${c.roundsBest6}회")
                        HorizontalDivider()
                        Text("전체 추천게임: 3개 ${c.ticketHit3} · 4개 ${c.ticketHit4} · 5개 ${c.ticketHit5} · 6개 ${c.ticketHit6}")
                        Text(
                            "무작위 기대: 3개 %.1f · 4개 %.2f · 5개 %.3f · 6개 %.4f".format(
                                c.randomExpectedTicket3,
                                c.randomExpectedTicket4,
                                c.randomExpectedTicket5,
                                c.randomExpectedTicket6
                            ),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
            item {
                Card {
                    Text(
                        "검증 원칙: 각 대상 회차의 당첨번호는 점수와 가중치를 만든 뒤에만 비교합니다. 해당 회차 정답이 학습 단계로 새어 들어가는 미래정보 누출을 방지합니다.",
                        Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

@Composable
private fun BacktestMetric(label: String, observed: Double, expected: Double, z: Double, evidence: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text("$label 평균 적중 %.2f / 7".format(observed), fontWeight = FontWeight.SemiBold)
        Text("무작위 기대 %.2f · z=%.2f · $evidence".format(expected, z), style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun WeightsScreen(modifier: Modifier, result: AnalysisResult?) {
    val numberPerf = result?.backtest?.performances.orEmpty().sortedByDescending { it.weight }
    LazyColumn(
        modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("자동 가중치", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("과거 Walk-forward 성적이 좋은 기법은 높이고, 성적이 약한 기법은 낮춥니다.")
        }
        if (result == null) {
            item { Text("분석을 먼저 실행하세요.") }
        } else {
            item { Text("번호 분석기법", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            items(numberPerf) { x ->
                Card {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(x.technique.label, fontWeight = FontWeight.Bold)
                            Text("%.1f%%".format(x.weight * 100), fontWeight = FontWeight.Bold)
                        }
                        LinearProgressIndicator(progress = { x.weight.toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                        Text(
                            "장기 %+.3f · 최근100 %+.3f · 최근50 %+.3f · 최근20 %+.3f".format(
                                x.longTermSkill,
                                x.recent100Skill,
                                x.recent50Skill,
                                x.recent20Skill
                            ),
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text("양(+) 창 %.0f%% · 안정성 %.0f%% · 표본 ${x.sampleCount}회".format(x.positiveWindowRate * 100, x.stability * 100), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item { Text("추천조합 구성요소", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            items(result.combinationBacktest.performances.sortedByDescending { it.weight }) { x ->
                Card {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(x.component.label, fontWeight = FontWeight.Bold)
                            Text("%.1f%%".format(x.weight * 100), fontWeight = FontWeight.Bold)
                        }
                        LinearProgressIndicator(progress = { x.weight.toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                        Text(
                            "장기 %+.3f · 최근50 %+.3f · 최근20 %+.3f · 표본 ${x.sampleCount}회".format(
                                x.longTermSkill,
                                x.recent50Skill,
                                x.recent20Skill
                            ),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun NumberRow(numbers: List<Int>, bonus: Int? = null) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        numbers.forEach { NumberBall(it) }
        if (bonus != null) {
            Text("+", fontWeight = FontWeight.Bold)
            NumberBall(bonus)
        }
    }
}

@Composable
private fun NumberBall(number: Int) {
    Surface(shape = CircleShape, tonalElevation = 3.dp) {
        Box(Modifier.size(38.dp), contentAlignment = Alignment.Center) {
            Text(number.toString(), fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        }
    }
}
