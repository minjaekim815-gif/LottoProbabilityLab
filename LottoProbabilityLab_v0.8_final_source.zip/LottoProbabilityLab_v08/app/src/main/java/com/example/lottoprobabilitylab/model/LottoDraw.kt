package com.example.lottoprobabilitylab.model

data class LottoDraw(
    val round: Int,
    val mainNumbers: List<Int>,
    val bonus: Int,
    val drawDate: String? = null
) {
    init {
        require(mainNumbers.size == 6)
        require(mainNumbers.distinct().size == 6)
        require(mainNumbers.all { it in 1..45 })
        require(bonus in 1..45 && bonus !in mainNumbers)
    }
    val allSeven: List<Int> get() = mainNumbers + bonus
    val mainSum: Int get() = mainNumbers.sum()
    val sevenSum: Int get() = allSeven.sum()
}
