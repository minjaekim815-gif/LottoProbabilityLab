package com.example.lottoprobabilitylab.engine

enum class Technique(val label: String) {
    LONG_FREQUENCY("장기 출현빈도"),
    RECENT_100("최근 100회 빈도"),
    RECENT_50("최근 50회 빈도"),
    RECENT_20("최근 20회 빈도"),
    GAP("출현 간격"),
    SUM_TRANSITION("보너스 포함 7개 합계 전이"),
    LAST_DRAW_REPEAT("직전회차 연속출현"),
    PAIR_LIFT("2개 동시출현 Pair/Lift"),
    TRIPLE_ASSOCIATION("3개 동시출현"),
    ANTI_PAIR("저동시출현/상극 관계"),
    CONDITIONAL("조건부 출현확률"),
    END_DIGIT("끝수 관계"),
    RANGE_BALANCE("구간 분포 적합도"),
    ODD_EVEN("홀짝 분포 적합도"),
    NEIGHBOR_DISTANCE("번호 간 거리"),
    PREVIOUS_OVERLAP("이전 회차 중복 패턴")
}
