package com.example.lottoprobabilitylab.ui

import com.example.lottoprobabilitylab.model.LottoDraw

object SampleData {
    // UI 구동 확인용 최소 샘플. 실제 버전에서는 전체 공식 회차 데이터를 저장/갱신한다.
    val draws = listOf(
        LottoDraw(1, listOf(10, 23, 29, 33, 37, 40), 16),
        LottoDraw(2, listOf(9, 13, 21, 25, 32, 42), 2),
        LottoDraw(3, listOf(11, 16, 19, 21, 27, 31), 30),
        LottoDraw(4, listOf(14, 27, 30, 31, 40, 42), 2),
        LottoDraw(5, listOf(16, 24, 29, 40, 41, 42), 3)
    )
}
