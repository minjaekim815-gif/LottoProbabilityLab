package com.example.lottoprobabilitylab.engine

import com.example.lottoprobabilitylab.model.LottoDraw
import kotlin.math.max

class NumberScorer {
    fun score(history: List<LottoDraw>): Map<Technique, Map<Int, Double>> {
        require(history.isNotEmpty())
        val all = history.map { it.allSeven.toSet() }
        val last = all.last()
        return mapOf(
            Technique.LONG_FREQUENCY to frequency(all),
            Technique.RECENT_100 to frequency(all.takeLast(100)),
            Technique.RECENT_50 to frequency(all.takeLast(50)),
            Technique.RECENT_20 to frequency(all.takeLast(20)),
            Technique.GAP to gapScore(all),
            Technique.SUM_TRANSITION to sumTransitionScore(history),
            Technique.LAST_DRAW_REPEAT to repeatScore(all),
            Technique.PAIR_LIFT to pairLiftScore(all, last),
            Technique.TRIPLE_ASSOCIATION to tripleAssociationScore(all, last),
            Technique.ANTI_PAIR to antiPairScore(all, last),
            Technique.CONDITIONAL to conditionalScore(all, last),
            Technique.END_DIGIT to endDigitScore(all, last),
            Technique.RANGE_BALANCE to rangeBalanceNumberScore(all),
            Technique.ODD_EVEN to oddEvenNumberScore(all),
            Technique.NEIGHBOR_DISTANCE to neighborDistanceNumberScore(history),
            Technique.PREVIOUS_OVERLAP to previousOverlapScore(all)
        )
    }

    private fun frequency(draws: List<Set<Int>>): Map<Int, Double> = normalize(
        (1..45).associateWith { n -> draws.count { n in it }.toDouble() / max(1, draws.size) }
    )

    private fun gapScore(draws: List<Set<Int>>): Map<Int, Double> {
        val raw = (1..45).associateWith { n ->
            val gaps = mutableListOf<Int>()
            var prev: Int? = null
            draws.forEachIndexed { i, s -> if (n in s) { prev?.let { gaps += i - it }; prev = i } }
            val currentGap = if (prev == null) draws.size else draws.lastIndex - prev!!
            if (gaps.size < 3) 0.5 else {
                // "오래 안 나왔으니 나올 때"라는 도박사의 오류를 피하고,
                // 해당 번호의 과거 재등장 간격 분포에 현재 gap이 얼마나 가까운지만 평가한다.
                val avg = gaps.average()
                val sigma = sd(gaps.map { it.toDouble() }).coerceAtLeast(1.0)
                gaussianScore(currentGap.toDouble(), avg, sigma * 1.5)
            }
        }
        return normalize(raw)
    }


    private fun sumTransitionScore(history: List<LottoDraw>): Map<Int, Double> {
        if (history.size < 30) return (1..45).associateWith { 0.5 }
        val currentSum = history.last().allSeven.sum().toDouble()
        val weightedHits = DoubleArray(46)
        var totalWeight = 0.0
        // 과거에 현재 회차 합계와 비슷한 회차가 있었을 때, 그 '다음 회차'에
        // 어떤 번호가 나왔는지를 커널 가중해 학습한다. 미래정보 누출 없이
        // walk-forward 백테스트에서 그대로 검증된다.
        for (i in 1 until history.size) {
            val previousSum = history[i - 1].allSeven.sum().toDouble()
            val distance = kotlin.math.abs(previousSum - currentSum)
            val weight = kotlin.math.exp(-distance / 28.0)
            history[i].allSeven.forEach { weightedHits[it] += weight }
            totalWeight += weight
        }
        if (totalWeight <= 1e-9) return (1..45).associateWith { 0.5 }
        val raw = (1..45).associateWith { n -> (weightedHits[n] + 0.25) / (totalWeight + 0.5) }
        return normalize(raw)
    }

    private fun repeatScore(draws: List<Set<Int>>): Map<Int, Double> {
        if (draws.size < 2) return (1..45).associateWith { 0.5 }
        var repeat = 0
        var opportunities = 0
        for (i in 1 until draws.size) { repeat += draws[i].intersect(draws[i - 1]).size; opportunities += 7 }
        val pRepeat = repeat.toDouble() / max(1, opportunities)
        val last = draws.last()
        return (1..45).associateWith { n -> if (n in last) pRepeat else (1 - pRepeat) * 7.0 / 38.0 }.let(::normalize)
    }

    private data class PairStats(val count: IntArray, val pair: Array<IntArray>, val total: Double)
    private fun pairStats(draws: List<Set<Int>>): PairStats {
        val count = IntArray(46); val pair = Array(46) { IntArray(46) }
        draws.forEach { s ->
            s.forEach { count[it]++ }
            val list = s.sorted()
            for (i in list.indices) for (j in i + 1 until list.size) { pair[list[i]][list[j]]++; pair[list[j]][list[i]]++ }
        }
        return PairStats(count, pair, draws.size.toDouble().coerceAtLeast(1.0))
    }

    private fun pairLiftScore(draws: List<Set<Int>>, last: Set<Int>): Map<Int, Double> {
        val ps = pairStats(draws)
        val raw = (1..45).associateWith { candidate ->
            last.filter { it != candidate }.map { anchor ->
                // Laplace smoothing으로 표본이 작은 pair의 과대평가를 완화한다.
                val observedConditional = (ps.pair[anchor][candidate] + 1.0) / (ps.count[anchor] + 2.0)
                val baseline = (ps.count[candidate] + 1.0) / (ps.total + 2.0)
                (observedConditional / baseline.coerceAtLeast(1e-9)).coerceIn(0.25, 4.0)
            }.averageOrHalf()
        }
        return normalize(raw)
    }

    private fun tripleAssociationScore(draws: List<Set<Int>>, last: Set<Int>): Map<Int, Double> {
        if (last.size < 2 || draws.size < 50) return (1..45).associateWith { 0.5 }
        val anchors = last.sorted()
        val anchorPairs = buildList {
            for (i in anchors.indices) for (j in i + 1 until anchors.size) add(anchors[i] to anchors[j])
        }
        val raw = (1..45).associateWith { candidate ->
            val vals = anchorPairs.filter { candidate != it.first && candidate != it.second }.map { (a, b) ->
                val ab = draws.count { a in it && b in it }
                val abc = draws.count { a in it && b in it && candidate in it }
                // Beta(1,3) shrinkage: 희소한 3개 조합이 1회 우연히 나온 경우를 과대평가하지 않는다.
                (abc + 1.0) / (ab + 4.0)
            }
            vals.averageOrHalf()
        }
        return normalize(raw)
    }

    private fun antiPairScore(draws: List<Set<Int>>, last: Set<Int>): Map<Int, Double> {
        val ps = pairStats(draws)
        val raw = (1..45).associateWith { candidate ->
            val penalties = last.filter { it != candidate }.map { anchor ->
                val expected = ps.count[anchor].toDouble() * ps.count[candidate] / ps.total
                val observed = ps.pair[anchor][candidate].toDouble()
                val support = minOf(ps.count[anchor], ps.count[candidate])
                if (support < 12) 0.5 else ((observed + 2.0) / (expected + 2.0)).coerceIn(0.15, 2.0) / 2.0
            }
            penalties.averageOrHalf()
        }
        return normalize(raw)
    }

    private fun conditionalScore(draws: List<Set<Int>>, last: Set<Int>): Map<Int, Double> {
        val raw = (1..45).associateWith { candidate ->
            val ps = last.filter { it != candidate }.map { anchor ->
                val anchorCount = draws.count { anchor in it }
                val both = draws.count { anchor in it && candidate in it }
                (both + 1.0) / (anchorCount + 2.0)
            }
            ps.averageOrHalf()
        }
        return normalize(raw)
    }

    private fun endDigitScore(draws: List<Set<Int>>, last: Set<Int>): Map<Int, Double> {
        val raw = (1..45).associateWith { n ->
            val digit = n % 10
            val lastSameDigits = last.count { it % 10 == digit }
            val historical = draws.map { s -> s.count { it % 10 == digit }.toDouble() }.average()
            gaussianScore(lastSameDigits.toDouble(), historical, 1.2)
        }
        return normalize(raw)
    }

    private fun rangeBalanceNumberScore(draws: List<Set<Int>>): Map<Int, Double> {
        fun bucket(n: Int) = when (n) { in 1..10 -> 0; in 11..20 -> 1; in 21..30 -> 2; in 31..40 -> 3; else -> 4 }
        val avg = DoubleArray(5)
        draws.forEach { s -> s.forEach { avg[bucket(it)]++ } }
        for (i in avg.indices) avg[i] = avg[i] / draws.size.coerceAtLeast(1).toDouble()
        return normalize((1..45).associateWith { n -> avg[bucket(n)] })
    }

    private fun oddEvenNumberScore(draws: List<Set<Int>>): Map<Int, Double> {
        val avgOdds = draws.map { s -> s.count { it % 2 == 1 }.toDouble() }.average()
        val oddPref = (avgOdds / 7.0).coerceIn(0.0, 1.0)
        return (1..45).associateWith { n -> if (n % 2 == 1) oddPref else 1.0 - oddPref }.let(::normalize)
    }

    private fun neighborDistanceNumberScore(draws: List<LottoDraw>): Map<Int, Double> {
        val distances = draws.flatMap { d -> d.allSeven.sorted().zipWithNext { a, b -> (b - a).toDouble() } }
        val center = if (distances.isEmpty()) 6.0 else distances.average()
        return normalize((1..45).associateWith { n ->
            val edgeDistance = minOf(n - 1, 45 - n).toDouble()
            gaussianScore(edgeDistance.coerceAtLeast(1.0), center * 1.5, 10.0)
        })
    }

    private fun previousOverlapScore(draws: List<Set<Int>>): Map<Int, Double> {
        if (draws.size < 3) return (1..45).associateWith { 0.5 }
        val overlap1 = (1 until draws.size).map { draws[it].intersect(draws[it - 1]).size.toDouble() }
        val overlap2 = (2 until draws.size).map { draws[it].intersect(draws[it - 2]).size.toDouble() }
        val m1 = overlap1.average() / 7.0; val m2 = overlap2.average() / 7.0
        val last = draws.last(); val prev2 = draws[draws.lastIndex - 1]
        return (1..45).associateWith { n -> when { n in last -> m1; n in prev2 -> m2; else -> ((1-m1)+(1-m2))/2.0 } }.let(::normalize)
    }

    private fun List<Double>.averageOrHalf(): Double = if (isEmpty()) 0.5 else average()
}
