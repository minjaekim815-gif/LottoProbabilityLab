package com.example.lottoprobabilitylab.engine

import com.example.lottoprobabilitylab.model.LottoDraw
import kotlin.math.abs
import kotlin.random.Random

enum class CombinationComponent(val label: String) {
    NUMBER_SCORE("번호 전망점수"),
    SUM_FIT("6개 합계"),
    ODD_EVEN_FIT("홀짝 구성"),
    RANGE_FIT("구간 분포"),
    CONSECUTIVE_FIT("연속번호"),
    OVERLAP_FIT("직전회차 중복"),
    PAIR_FIT("Pair/Lift 적합도")
}

data class CombinationComponentPerformance(
    val component: CombinationComponent,
    val longTermSkill: Double,
    val recent50Skill: Double,
    val recent20Skill: Double,
    val weight: Double,
    val sampleCount: Int
)

data class CombinationWeights(val values: Map<CombinationComponent, Double>) {
    fun get(component: CombinationComponent): Double = values[component] ?: 0.0

    companion object {
        fun default(): CombinationWeights = CombinationWeights(
            mapOf(
                CombinationComponent.NUMBER_SCORE to 0.46,
                CombinationComponent.SUM_FIT to 0.14,
                CombinationComponent.ODD_EVEN_FIT to 0.08,
                CombinationComponent.RANGE_FIT to 0.08,
                CombinationComponent.CONSECUTIVE_FIT to 0.07,
                CombinationComponent.OVERLAP_FIT to 0.07,
                CombinationComponent.PAIR_FIT to 0.10
            )
        )
    }
}

data class CombinationCandidate(
    val numbers: List<Int>,
    val score: Double,
    val numberScore: Double,
    val sumFit: Double,
    val oddEvenFit: Double,
    val rangeFit: Double,
    val consecutiveFit: Double,
    val overlapFit: Double,
    val pairFit: Double
) {
    fun componentValue(component: CombinationComponent): Double = when (component) {
        CombinationComponent.NUMBER_SCORE -> numberScore
        CombinationComponent.SUM_FIT -> sumFit
        CombinationComponent.ODD_EVEN_FIT -> oddEvenFit
        CombinationComponent.RANGE_FIT -> rangeFit
        CombinationComponent.CONSECUTIVE_FIT -> consecutiveFit
        CombinationComponent.OVERLAP_FIT -> overlapFit
        CombinationComponent.PAIR_FIT -> pairFit
    }
}

internal data class CombinationContext(
    val historySize: Int,
    val sums: List<Double>,
    val sumMaxDensity: Double,
    val oddCounts: List<Int>,
    val oddMaxCount: Int,
    val avgBuckets: DoubleArray,
    val consecutiveCounts: List<Int>,
    val consecutiveMaxCount: Int,
    val overlapCounts: List<Int>,
    val overlapMaxCount: Int,
    val previousMain: Set<Int>,
    val numberCount: IntArray,
    val pairCount: Array<IntArray>
)

class CombinationEngine {
    fun generate(
        history: List<LottoDraw>,
        numberScores: Map<Int, Double>,
        count: Int = 10,
        trials: Int = 40_000,
        seed: Int = 645,
        weights: CombinationWeights = CombinationWeights.default()
    ): List<CombinationCandidate> {
        require(history.isNotEmpty())
        val context = buildContext(history)
        return generateWithContext(context, numberScores, count, trials, seed + history.last().round, weights)
    }

    internal fun generateWithContext(
        context: CombinationContext,
        numberScores: Map<Int, Double>,
        count: Int,
        trials: Int,
        seed: Int,
        weights: CombinationWeights
    ): List<CombinationCandidate> {
        val random = Random(seed)
        val candidates = HashMap<List<Int>, CombinationCandidate>()
        repeat(trials) {
            val combo = weightedSampleWithoutReplacement(numberScores, 6, random).sorted()
            candidates.putIfAbsent(combo, evaluate(context, numberScores, combo, weights))
        }
        val ranked = candidates.values.sortedByDescending { it.score }

        // 추천 게임끼리 5개 이상 겹치지 않게 하여 후보군 다양성을 확보한다.
        val selected = mutableListOf<CombinationCandidate>()
        for (c in ranked) {
            val tooSimilar = selected.any { existing -> c.numbers.intersect(existing.numbers.toSet()).size >= 5 }
            if (!tooSimilar) selected += c
            if (selected.size >= count) break
        }
        if (selected.size < count) {
            ranked.filter { it !in selected }.take(count - selected.size).forEach { selected += it }
        }
        return selected
    }

    internal fun buildContext(history: List<LottoDraw>): CombinationContext {
        require(history.isNotEmpty())
        val historicalSix = history.map { it.mainNumbers.sorted() }
        val sums = historicalSix.map { it.sum().toDouble() }
        val oddCounts = historicalSix.map { it.count { n -> n % 2 == 1 } }

        val avgBuckets = DoubleArray(5)
        historicalSix.forEach { d -> d.forEach { avgBuckets[bucket(it)]++ } }
        avgBuckets.indices.forEach { i -> avgBuckets[i] = avgBuckets[i] / historicalSix.size }

        val consecutiveCounts = historicalSix.map { d -> d.zipWithNext().count { (a, b) -> b - a == 1 } }
        val overlapCounts = (1 until historicalSix.size).map { i -> historicalSix[i].intersect(historicalSix[i - 1].toSet()).size }
        val sumMaxDensity = maxWindowDensity(sums, 9.0)
        val oddMaxCount = maxDiscreteCount(oddCounts, 6)
        val consecutiveMaxCount = maxDiscreteCount(consecutiveCounts, 5)
        val overlapMaxCount = maxDiscreteCount(overlapCounts, 6)

        val numberCount = IntArray(46)
        val pairCount = Array(46) { IntArray(46) }
        history.forEach { draw ->
            val s = draw.allSeven.toSet()
            s.forEach { numberCount[it]++ }
            val l = s.toList()
            for (i in l.indices) for (j in i + 1 until l.size) {
                pairCount[l[i]][l[j]]++
                pairCount[l[j]][l[i]]++
            }
        }
        return CombinationContext(
            historySize = history.size,
            sums = sums,
            sumMaxDensity = sumMaxDensity,
            oddCounts = oddCounts,
            oddMaxCount = oddMaxCount,
            avgBuckets = avgBuckets,
            consecutiveCounts = consecutiveCounts,
            consecutiveMaxCount = consecutiveMaxCount,
            overlapCounts = overlapCounts,
            overlapMaxCount = overlapMaxCount,
            previousMain = history.last().mainNumbers.toSet(),
            numberCount = numberCount,
            pairCount = pairCount
        )
    }

    internal fun evaluate(
        context: CombinationContext,
        scores: Map<Int, Double>,
        combo: List<Int>,
        weights: CombinationWeights
    ): CombinationCandidate {
        val sorted = combo.sorted()
        val sumFit = empiricalFit(sorted.sum().toDouble(), context.sums, bandwidth = 9.0, maxDensity = context.sumMaxDensity)
        val oddEvenFit = empiricalDiscreteFit(sorted.count { it % 2 == 1 }, context.oddCounts, 6, context.oddMaxCount)

        val comboBuckets = IntArray(5)
        sorted.forEach { comboBuckets[bucket(it)]++ }
        val rangeError = comboBuckets.indices.sumOf { abs(comboBuckets[it] - context.avgBuckets[it]) }
        val rangeFit = (1.0 - rangeError / 12.0).coerceIn(0.0, 1.0)

        val comboConsecutive = sorted.zipWithNext().count { (a, b) -> b - a == 1 }
        val consecutiveFit = empiricalDiscreteFit(comboConsecutive, context.consecutiveCounts, 5, context.consecutiveMaxCount)
        val overlapFit = empiricalDiscreteFit(sorted.intersect(context.previousMain).size, context.overlapCounts, 6, context.overlapMaxCount)
        val pairFit = pairCompatibility(context, sorted)
        val numberScore = sorted.map { scores[it] ?: 0.0 }.average()

        val values = mapOf(
            CombinationComponent.NUMBER_SCORE to numberScore,
            CombinationComponent.SUM_FIT to sumFit,
            CombinationComponent.ODD_EVEN_FIT to oddEvenFit,
            CombinationComponent.RANGE_FIT to rangeFit,
            CombinationComponent.CONSECUTIVE_FIT to consecutiveFit,
            CombinationComponent.OVERLAP_FIT to overlapFit,
            CombinationComponent.PAIR_FIT to pairFit
        )
        val final = CombinationComponent.entries.sumOf { c -> weights.get(c) * values.getValue(c) }
        return CombinationCandidate(sorted, final, numberScore, sumFit, oddEvenFit, rangeFit, consecutiveFit, overlapFit, pairFit)
    }

    internal fun randomBaselineCandidates(
        context: CombinationContext,
        numberScores: Map<Int, Double>,
        count: Int,
        seed: Int,
        weights: CombinationWeights = CombinationWeights.default()
    ): List<CombinationCandidate> {
        val random = Random(seed)
        return List(count) {
            val combo = (1..45).shuffled(random).take(6).sorted()
            evaluate(context, numberScores, combo, weights)
        }
    }

    private fun bucket(n: Int) = when (n) {
        in 1..10 -> 0
        in 11..20 -> 1
        in 21..30 -> 2
        in 31..40 -> 3
        else -> 4
    }

    private fun empiricalFit(x: Double, history: List<Double>, bandwidth: Double, maxDensity: Double): Double {
        if (history.isEmpty()) return 0.5
        val close = history.count { abs(it - x) <= bandwidth }.toDouble() / history.size
        return (close / maxDensity.coerceAtLeast(1e-9)).coerceIn(0.0, 1.0)
    }

    private fun maxWindowDensity(history: List<Double>, bandwidth: Double): Double {
        if (history.isEmpty()) return 1.0
        val sorted = history.sorted()
        var left = 0
        var best = 1
        for (right in sorted.indices) {
            while (sorted[right] - sorted[left] > bandwidth * 2.0) left++
            best = maxOf(best, right - left + 1)
        }
        return best.toDouble() / history.size
    }

    private fun empiricalDiscreteFit(x: Int, history: List<Int>, maxValue: Int, maxCount: Int): Double {
        if (history.isEmpty()) return 0.5
        if (x !in 0..maxValue) return 0.0
        val count = history.count { it == x }
        return count.toDouble() / maxCount.coerceAtLeast(1)
    }

    private fun maxDiscreteCount(history: List<Int>, maxValue: Int): Int {
        val counts = IntArray(maxValue + 1)
        history.filter { it in counts.indices }.forEach { counts[it]++ }
        return counts.maxOrNull()?.coerceAtLeast(1) ?: 1
    }

    private fun pairCompatibility(context: CombinationContext, combo: List<Int>): Double {
        val total = context.historySize.toDouble().coerceAtLeast(1.0)
        val lifts = mutableListOf<Double>()
        for (i in combo.indices) for (j in i + 1 until combo.size) {
            val a = combo[i]
            val b = combo[j]
            val pB = (context.numberCount[b] + 1.0) / (total + 2.0)
            val pBgivenA = (context.pairCount[a][b] + 1.0) / (context.numberCount[a] + 2.0)
            lifts += (pBgivenA / pB.coerceAtLeast(1e-9)).coerceIn(0.25, 3.0) / 3.0
        }
        return lifts.averageOrZero().coerceIn(0.0, 1.0)
    }

    private fun weightedSampleWithoutReplacement(scores: Map<Int, Double>, k: Int, random: Random): List<Int> {
        val pool = (1..45).toMutableList()
        val out = mutableListOf<Int>()
        repeat(k) {
            val weights = pool.map { ((scores[it] ?: 0.0) + 0.05).coerceAtLeast(0.01) }
            val total = weights.sum()
            var r = random.nextDouble() * total
            var idx = 0
            while (idx < pool.lastIndex && r > weights[idx]) {
                r -= weights[idx]
                idx++
            }
            out += pool.removeAt(idx)
        }
        return out
    }

    private fun List<Double>.averageOrZero(): Double = if (isEmpty()) 0.0 else average()
}
