package com.example.lottoprobabilitylab.engine

import com.example.lottoprobabilitylab.model.LottoDraw
import kotlin.math.max

/**
 * 추천 10게임을 과거 시점에서 실제로 생성해 보는 조합 단위 Walk-forward 검증.
 * 번호점수는 BacktestEngine이 해당 과거 시점 이전 데이터만으로 만든 snapshot을 사용한다.
 */
data class CombinationBacktestSummary(
    val performances: List<CombinationComponentPerformance>,
    val finalWeights: CombinationWeights,
    val testedRounds: Int,
    val ticketsPerRound: Int,
    val averageBestHits: Double,
    val roundsBest3Plus: Int,
    val roundsBest4Plus: Int,
    val roundsBest5Plus: Int,
    val roundsBest6: Int,
    val ticketHit3: Int,
    val ticketHit4: Int,
    val ticketHit5: Int,
    val ticketHit6: Int,
    val randomExpectedTicket3: Double,
    val randomExpectedTicket4: Double,
    val randomExpectedTicket5: Double,
    val randomExpectedTicket6: Double
)

class CombinationBacktestEngine(
    private val combinationEngine: CombinationEngine = CombinationEngine(),
    private val maxRounds: Int = 120,
    private val ticketsPerRound: Int = 10,
    private val trialsPerRound: Int = 1_500,
    private val baselineSamples: Int = 240
) {
    fun run(
        draws: List<LottoDraw>,
        numberScoreSnapshots: Map<Int, Map<Int, Double>>
    ): CombinationBacktestSummary {
        if (draws.size < 121 || numberScoreSnapshots.isEmpty()) return neutral()

        val start = max(120, draws.size - maxRounds)
        val skills = CombinationComponent.entries.associateWith { mutableListOf<Double>() }
        var tested = 0
        var bestHitsTotal = 0.0
        var rounds3 = 0; var rounds4 = 0; var rounds5 = 0; var rounds6 = 0
        var ticket3 = 0; var ticket4 = 0; var ticket5 = 0; var ticket6 = 0

        for (targetIndex in start until draws.size) {
            val targetDraw = draws[targetIndex]
            val numberScores = numberScoreSnapshots[targetDraw.round] ?: continue
            val history = draws.subList(0, targetIndex)
            val context = combinationEngine.buildContext(history)

            // 정답을 보기 전까지 누적된 조합 구성요소 성적으로 현재 시점의 가중치를 만든다.
            val currentPerf = performancesFrom(skills)
            val currentWeights = CombinationWeights(currentPerf.associate { it.component to it.weight })
            val recommended = combinationEngine.generateWithContext(
                context = context,
                numberScores = numberScores,
                count = ticketsPerRound,
                trials = trialsPerRound,
                seed = 645_000 + targetDraw.round,
                weights = currentWeights
            )

            val actual = targetDraw.mainNumbers.toSet()
            val hitCounts = recommended.map { it.numbers.count(actual::contains) }
            val best = hitCounts.maxOrNull() ?: 0
            bestHitsTotal += best
            if (best >= 3) rounds3++
            if (best >= 4) rounds4++
            if (best >= 5) rounds5++
            if (best >= 6) rounds6++
            ticket3 += hitCounts.count { it == 3 }
            ticket4 += hitCounts.count { it == 4 }
            ticket5 += hitCounts.count { it == 5 }
            ticket6 += hitCounts.count { it == 6 }

            // 실제 정답조합의 각 구성요소 값이 같은 시점의 무작위 6개 조합 대비 어느 백분위인지 평가한다.
            val actualCandidate = combinationEngine.evaluate(context, numberScores, targetDraw.mainNumbers, currentWeights)
            val baseline = combinationEngine.randomBaselineCandidates(
                context, numberScores, baselineSamples,
                seed = 911_000 + targetDraw.round,
                weights = currentWeights
            )
            CombinationComponent.entries.forEach { component ->
                val actualValue = actualCandidate.componentValue(component)
                val below = baseline.count { it.componentValue(component) < actualValue }
                val equal = baseline.count { it.componentValue(component) == actualValue }
                val percentile = (below + 0.5 * equal) / baseline.size.toDouble()
                val skill = ((percentile - 0.5) * 2.0).coerceIn(-1.0, 1.0)
                skills.getValue(component).add(skill)
            }
            tested++
        }

        if (tested == 0) return neutral()
        val performances = performancesFrom(skills)
        val totalTickets = tested * ticketsPerRound
        return CombinationBacktestSummary(
            performances = performances,
            finalWeights = CombinationWeights(performances.associate { it.component to it.weight }),
            testedRounds = tested,
            ticketsPerRound = ticketsPerRound,
            averageBestHits = bestHitsTotal / tested,
            roundsBest3Plus = rounds3,
            roundsBest4Plus = rounds4,
            roundsBest5Plus = rounds5,
            roundsBest6 = rounds6,
            ticketHit3 = ticket3,
            ticketHit4 = ticket4,
            ticketHit5 = ticket5,
            ticketHit6 = ticket6,
            randomExpectedTicket3 = totalTickets * exactMatchProbability(3),
            randomExpectedTicket4 = totalTickets * exactMatchProbability(4),
            randomExpectedTicket5 = totalTickets * exactMatchProbability(5),
            randomExpectedTicket6 = totalTickets * exactMatchProbability(6)
        )
    }

    private fun performancesFrom(history: Map<CombinationComponent, List<Double>>): List<CombinationComponentPerformance> {
        val raw = CombinationComponent.entries.map { component ->
            val all = history[component].orEmpty()
            val long = all.averageOrZero()
            val recent50 = all.takeLast(50).averageOrZero()
            val recent20 = all.takeLast(20).averageOrZero()
            val blended = 0.50 * long + 0.30 * recent50 + 0.20 * recent20
            val shrink = all.size.toDouble() / (all.size + 60.0)
            val adjusted = blended * shrink
            // 어느 한 구성요소도 5% 미만/45% 초과가 되지 않게 완만하게 제한한다.
            val rawWeight = (1.0 + 1.6 * adjusted).coerceIn(0.45, 2.00)
            CombinationComponentPerformance(component, long, recent50, recent20, rawWeight, all.size)
        }
        val sum = raw.sumOf { it.weight }.coerceAtLeast(1e-9)
        var normalized = raw.map { it.copy(weight = it.weight / sum) }
        repeat(4) {
            val capped = normalized.map { it.copy(weight = it.weight.coerceIn(0.05, 0.45)) }
            val s = capped.sumOf { it.weight }.coerceAtLeast(1e-9)
            normalized = capped.map { it.copy(weight = it.weight / s) }
        }
        return normalized
    }

    private fun exactMatchProbability(k: Int): Double {
        // 한 게임(6개)이 실제 당첨 6개와 정확히 k개 일치할 확률: C(6,k)C(39,6-k)/C(45,6)
        if (k !in 0..6) return 0.0
        return combination(6, k) * combination(39, 6 - k) / combination(45, 6)
    }

    private fun combination(n: Int, r: Int): Double {
        if (r < 0 || r > n) return 0.0
        val rr = minOf(r, n - r)
        var out = 1.0
        for (i in 1..rr) out = out * (n - rr + i) / i
        return out
    }

    private fun List<Double>.averageOrZero(): Double = if (isEmpty()) 0.0 else average()

    private fun neutral(): CombinationBacktestSummary {
        val defaults = CombinationWeights.default()
        val perf = CombinationComponent.entries.map {
            CombinationComponentPerformance(it, 0.0, 0.0, 0.0, defaults.get(it), 0)
        }
        return CombinationBacktestSummary(
            performances = perf,
            finalWeights = defaults,
            testedRounds = 0,
            ticketsPerRound = ticketsPerRound,
            averageBestHits = 0.0,
            roundsBest3Plus = 0, roundsBest4Plus = 0, roundsBest5Plus = 0, roundsBest6 = 0,
            ticketHit3 = 0, ticketHit4 = 0, ticketHit5 = 0, ticketHit6 = 0,
            randomExpectedTicket3 = 0.0, randomExpectedTicket4 = 0.0,
            randomExpectedTicket5 = 0.0, randomExpectedTicket6 = 0.0
        )
    }
}
