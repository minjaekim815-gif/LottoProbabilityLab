package com.example.lottoprobabilitylab.engine

import com.example.lottoprobabilitylab.model.LottoDraw

data class AnalysisResult(
    val nextRound: Int,
    val numberRanking: List<Pair<Int, Double>>,
    val outlookSeven: List<Int>,
    val combinations: List<CombinationCandidate>,
    val backtest: BacktestSummary,
    val combinationBacktest: CombinationBacktestSummary,
    val holdoutValidation: HoldoutValidationSummary
)

class LottoAnalysisEngine(
    private val backtestEngine: BacktestEngine = BacktestEngine(),
    private val combinationEngine: CombinationEngine = CombinationEngine(),
    private val combinationBacktestEngine: CombinationBacktestEngine = CombinationBacktestEngine(),
    private val finalValidationEngine: FinalValidationEngine = FinalValidationEngine()
) {
    fun analyze(draws: List<LottoDraw>): AnalysisResult {
        require(draws.isNotEmpty())
        val sorted = draws.sortedBy { it.round }

        // 번호 모델의 최근 과거 시점별 점수 snapshot을 함께 보관해 조합 백테스트에 사용한다.
        val detailed = backtestEngine.runDetailed(sorted, captureLastRounds = 140)
        val backtest = detailed.summary
        val combinationBacktest = combinationBacktestEngine.run(sorted, detailed.numberScoreSnapshots)
        val holdoutValidation = finalValidationEngine.run(sorted)

        val nextScores = backtestEngine.scoreNext(sorted, backtest)
        val ranking = nextScores.entries.sortedByDescending { it.value }.map { it.key to it.value }
        val combos = combinationEngine.generate(
            history = sorted,
            numberScores = nextScores,
            weights = combinationBacktest.finalWeights
        )

        return AnalysisResult(
            nextRound = sorted.last().round + 1,
            numberRanking = ranking,
            outlookSeven = ranking.take(7).map { it.first }.sorted(),
            combinations = combos,
            backtest = backtest,
            combinationBacktest = combinationBacktest,
            holdoutValidation = holdoutValidation
        )
    }
}
