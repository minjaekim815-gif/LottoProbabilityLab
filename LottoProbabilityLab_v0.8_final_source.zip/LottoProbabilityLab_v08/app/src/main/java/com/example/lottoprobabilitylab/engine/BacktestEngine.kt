package com.example.lottoprobabilitylab.engine

import com.example.lottoprobabilitylab.model.LottoDraw
import kotlin.math.sqrt

data class TechniquePerformance(
    val technique: Technique,
    val longTermSkill: Double,
    val recent100Skill: Double,
    val recent50Skill: Double,
    val recent20Skill: Double,
    val positiveWindowRate: Double,
    val stability: Double,
    val weight: Double,
    val sampleCount: Int
)

data class BacktestSummary(
    val performances: List<TechniquePerformance>,
    val averageHitsTop10: Double,
    val averageHitsTop15: Double,
    val averageHitsTop20: Double,
    val randomExpectedTop10: Double,
    val randomExpectedTop15: Double,
    val randomExpectedTop20: Double,
    val zTop10: Double,
    val zTop15: Double,
    val zTop20: Double,
    val testedRounds: Int
) {
    val liftTop10: Double get() = if (randomExpectedTop10 == 0.0) 0.0 else averageHitsTop10 / randomExpectedTop10
    val liftTop15: Double get() = if (randomExpectedTop15 == 0.0) 0.0 else averageHitsTop15 / randomExpectedTop15
    val liftTop20: Double get() = if (randomExpectedTop20 == 0.0) 0.0 else averageHitsTop20 / randomExpectedTop20

    fun evidenceLabel(z: Double): String = when {
        z >= 2.58 -> "강함"
        z >= 1.96 -> "있음"
        z >= 1.00 -> "약함"
        z <= -1.96 -> "무작위보다 낮음"
        else -> "뚜렷하지 않음"
    }
}

data class BacktestDetailedResult(
    val summary: BacktestSummary,
    val numberScoreSnapshots: Map<Int, Map<Int, Double>>
)

class BacktestEngine(
    private val scorer: NumberScorer = NumberScorer(),
    private val minHistory: Int = 120
) {
    private data class Row(val skills: Map<Technique, Double>, val h10: Int, val h15: Int, val h20: Int)

    fun run(draws: List<LottoDraw>): BacktestSummary = runDetailed(draws, 0).summary

    fun runDetailed(draws: List<LottoDraw>, captureLastRounds: Int = 160): BacktestDetailedResult {
        if (draws.size <= minHistory) return BacktestDetailedResult(neutral(), emptyMap())

        val rows = mutableListOf<Row>()
        val snapshots = linkedMapOf<Int, Map<Int, Double>>()
        val skillHistory = Technique.entries.associateWith { mutableListOf<Double>() }
        val captureFromIndex = if (captureLastRounds <= 0) Int.MAX_VALUE else (draws.size - captureLastRounds).coerceAtLeast(minHistory)

        for (targetIndex in minHistory until draws.size) {
            val history = draws.subList(0, targetIndex)
            val target = draws[targetIndex].allSeven.toSet()
            val techniqueScores = scorer.score(history)

            // target 회차의 정답을 보기 전에, 그 이전 백테스트 성적만으로 가중치를 만든다.
            val preTargetWeights = buildWeights(skillHistory)
            val aggregate = aggregate(techniqueScores, preTargetWeights)
            if (targetIndex >= captureFromIndex) snapshots[draws[targetIndex].round] = normalize(aggregate)
            val perTechniqueSkill = Technique.entries.associateWith { t -> rankSkill(techniqueScores.getValue(t), target) }

            rows += Row(
                skills = perTechniqueSkill,
                h10 = hits(aggregate, target, 10),
                h15 = hits(aggregate, target, 15),
                h20 = hits(aggregate, target, 20)
            )
            perTechniqueSkill.forEach { (t, v) -> skillHistory.getValue(t).add(v) }
        }

        val perf = performancesFrom(skillHistory)
        val n = rows.size
        val avg10 = rows.map { it.h10.toDouble() }.averageOrZero()
        val avg15 = rows.map { it.h15.toDouble() }.averageOrZero()
        val avg20 = rows.map { it.h20.toDouble() }.averageOrZero()
        val e10 = 7.0 * 10 / 45.0
        val e15 = 7.0 * 15 / 45.0
        val e20 = 7.0 * 20 / 45.0
        val summary = BacktestSummary(
            performances = perf,
            averageHitsTop10 = avg10,
            averageHitsTop15 = avg15,
            averageHitsTop20 = avg20,
            randomExpectedTop10 = e10,
            randomExpectedTop15 = e15,
            randomExpectedTop20 = e20,
            zTop10 = zAgainstRandom(avg10, 10, n),
            zTop15 = zAgainstRandom(avg15, 15, n),
            zTop20 = zAgainstRandom(avg20, 20, n),
            testedRounds = n
        )
        return BacktestDetailedResult(summary, snapshots)
    }

    fun scoreNext(draws: List<LottoDraw>, backtest: BacktestSummary): Map<Int, Double> {
        val scores = scorer.score(draws)
        val weights = backtest.performances.associate { it.technique to it.weight }
        return aggregate(scores, weights).let(::normalize)
    }

    private fun performancesFrom(skillHistory: Map<Technique, List<Double>>): List<TechniquePerformance> {
        val raw = Technique.entries.map { t ->
            val all = skillHistory[t].orEmpty()
            val l = all.averageOrZero(); val r100 = all.takeLast(100).averageOrZero()
            val r50 = all.takeLast(50).averageOrZero(); val r20 = all.takeLast(20).averageOrZero()
            val blended = 0.40*l + 0.30*r100 + 0.20*r50 + 0.10*r20

            // 20회 단위 창에서도 반복적으로 양(+)의 기술을 보이는지 확인한다.
            val windows = all.chunked(20).filter { it.size >= 10 }.map { it.average() }
            val positiveRate = if (windows.isEmpty()) 0.5 else windows.count { it > 0.0 }.toDouble() / windows.size
            val stability = if (windows.size < 2) 0.5 else (1.0 / (1.0 + sd(windows))).coerceIn(0.0, 1.0)

            // 작은 표본은 무작위 수준(0) 쪽으로 수축하고, 일시적 성과는 안정성 페널티를 준다.
            val shrink = all.size.toDouble() / (all.size + 100.0)
            val adjusted = blended * shrink
            val consistencyFactor = 0.70 + 0.20 * positiveRate + 0.10 * stability
            val rawWeight = ((1.0 + 1.8 * adjusted) * consistencyFactor).coerceIn(0.35, 2.20)
            TechniquePerformance(t, l, r100, r50, r20, positiveRate, stability, rawWeight, all.size)
        }
        return normalizeWeightsWithFamilyCaps(raw)
    }

    /**
     * 서로 비슷한 기법을 여러 개 넣었다는 이유만으로 한 계열이 전체 모델을 장악하지 못하도록
     * 기법군별 총 가중치를 최대 40%로 제한한다.
     */
    private fun normalizeWeightsWithFamilyCaps(raw: List<TechniquePerformance>): List<TechniquePerformance> {
        val familyOf: (Technique) -> Int = { t -> when (t) {
            Technique.LONG_FREQUENCY, Technique.RECENT_100, Technique.RECENT_50, Technique.RECENT_20 -> 0
            Technique.GAP, Technique.SUM_TRANSITION, Technique.LAST_DRAW_REPEAT, Technique.PREVIOUS_OVERLAP -> 1
            Technique.PAIR_LIFT, Technique.TRIPLE_ASSOCIATION, Technique.ANTI_PAIR, Technique.CONDITIONAL -> 2
            Technique.END_DIGIT, Technique.RANGE_BALANCE, Technique.ODD_EVEN, Technique.NEIGHBOR_DISTANCE -> 3
        } }
        val baseSum = raw.sumOf { it.weight }.coerceAtLeast(1e-9)
        val base = raw.associate { it.technique to it.weight / baseSum }.toMutableMap()

        repeat(3) {
            val familyTotals = base.entries.groupBy { familyOf(it.key) }.mapValues { e -> e.value.sumOf { it.value } }
            familyTotals.filterValues { it > 0.40 }.forEach { (family, total) ->
                val scale = 0.40 / total
                base.keys.filter { familyOf(it) == family }.forEach { base[it] = base.getValue(it) * scale }
            }
            val s = base.values.sum().coerceAtLeast(1e-9)
            base.keys.forEach { base[it] = base.getValue(it) / s }
        }
        val finalSum = base.values.sum().coerceAtLeast(1e-9)
        return raw.map { it.copy(weight = base.getValue(it.technique) / finalSum) }
    }

    private fun buildWeights(skillHistory: Map<Technique, List<Double>>): Map<Technique, Double> =
        performancesFrom(skillHistory).associate { it.technique to it.weight }

    private fun neutral(): BacktestSummary {
        val w = 1.0 / Technique.entries.size
        val p = Technique.entries.map { TechniquePerformance(it,0.0,0.0,0.0,0.0,0.5,0.5,w,0) }
        return BacktestSummary(p,0.0,0.0,0.0,7.0*10/45.0,7.0*15/45.0,7.0*20/45.0,0.0,0.0,0.0,0)
    }

    private fun rankSkill(scores: Map<Int, Double>, actual: Set<Int>): Double {
        val ranked = scores.entries.sortedByDescending { it.value }.map { it.key }
        val percentiles = actual.map { n ->
            val idx = ranked.indexOf(n)
            val rank = if (idx < 0) 44 else idx
            1.0 - rank.toDouble() / 44.0
        }
        return ((percentiles.average() - 0.5) * 2.0).coerceIn(-1.0, 1.0)
    }

    private fun aggregate(techniqueScores: Map<Technique, Map<Int, Double>>, weights: Map<Technique, Double>): Map<Int, Double> =
        (1..45).associateWith { n -> techniqueScores.entries.sumOf { (t,m) -> m.getValue(n) * (weights[t] ?: 0.0) } }

    private fun hits(scores: Map<Int, Double>, actual: Set<Int>, k: Int): Int =
        scores.entries.sortedByDescending { it.value }.take(k).count { it.key in actual }

    // 무작위 Top-k와 7개 실제번호의 교집합은 Hypergeometric(45,7,k)을 따른다.
    private fun zAgainstRandom(observedMean: Double, k: Int, rounds: Int): Double {
        if (rounds <= 0) return 0.0
        val p = 7.0 / 45.0
        val varianceOne = k * p * (1.0 - p) * ((45.0 - k) / 44.0)
        val se = sqrt(varianceOne / rounds).coerceAtLeast(1e-9)
        val expected = 7.0 * k / 45.0
        return (observedMean - expected) / se
    }

    private fun List<Double>.averageOrZero(): Double = if (isEmpty()) 0.0 else average()
}
