package com.example.lottoprobabilitylab.data

import android.content.Context
import com.example.lottoprobabilitylab.model.LottoDraw
import org.json.JSONArray
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * 로또 회차 데이터 저장소.
 *
 * - 정상적으로 내려받은 전체 회차 JSON을 앱 내부 저장소에 영구 캐시한다.
 * - 앱 실행 시 온라인 데이터를 확인하고 기존 캐시의 마지막 회차와 비교한다.
 * - 새 회차가 있으면 캐시를 교체하고 newRounds를 반환한다.
 * - 네트워크 실패 시 마지막 정상 캐시로 자동 폴백한다.
 */
class LottoRepository(private val context: Context) {
    private val cacheFile = File(context.filesDir, "lotto_history.json")
    private val prefs = context.getSharedPreferences("lotto_sync", Context.MODE_PRIVATE)
    private val remoteUrl = "https://smok95.github.io/lotto/results/all.json"

    data class LoadResult(
        val draws: List<LottoDraw>,
        val source: String,
        /** 온라인에서 실제로 더 최신 회차를 받아 캐시가 바뀌었는지 */
        val refreshed: Boolean,
        /** 온라인 최신 여부 확인 자체를 성공했는지 */
        val checkedOnline: Boolean,
        val previousRound: Int?,
        val latestRound: Int,
        val newRounds: Int,
        val lastSyncEpochMillis: Long?,
        val warning: String? = null
    )

    fun load(refresh: Boolean = true): LoadResult {
        val cachedBefore = readValidCacheOrNull()
        val previousRound = cachedBefore?.lastOrNull()?.round

        if (refresh) {
            try {
                val json = download(remoteUrl)
                val online = parse(json)
                validate(online)

                val latestRound = online.last().round
                val newRounds = if (previousRound == null) latestRound else (latestRound - previousRound).coerceAtLeast(0)

                // 정상 검증된 데이터만 원자적으로 교체한다.
                atomicWriteCache(json)
                val now = System.currentTimeMillis()
                prefs.edit()
                    .putInt("last_known_round", latestRound)
                    .putLong("last_sync_ms", now)
                    .apply()

                return LoadResult(
                    draws = online,
                    source = if (previousRound == null) "온라인 전체회차 · 최초 저장" else "온라인 최신 확인",
                    refreshed = previousRound == null || latestRound > previousRound,
                    checkedOnline = true,
                    previousRound = previousRound,
                    latestRound = latestRound,
                    newRounds = newRounds,
                    lastSyncEpochMillis = now,
                    warning = "외부 미러 데이터입니다. 당첨 결과는 동행복권 공식 결과와 교차확인하세요."
                )
            } catch (t: Throwable) {
                if (cachedBefore != null) {
                    val lastSync = prefs.getLong("last_sync_ms", 0L).takeIf { it > 0L }
                    return LoadResult(
                        draws = cachedBefore,
                        source = "로컬 저장 데이터",
                        refreshed = false,
                        checkedOnline = false,
                        previousRound = previousRound,
                        latestRound = cachedBefore.last().round,
                        newRounds = 0,
                        lastSyncEpochMillis = lastSync,
                        warning = "온라인 최신 확인 실패 · 마지막 정상 저장 데이터 사용: ${t.message ?: t.javaClass.simpleName}"
                    )
                }
                throw t
            }
        }

        if (cachedBefore != null) {
            val lastSync = prefs.getLong("last_sync_ms", 0L).takeIf { it > 0L }
            return LoadResult(
                draws = cachedBefore,
                source = "로컬 저장 데이터",
                refreshed = false,
                checkedOnline = false,
                previousRound = previousRound,
                latestRound = cachedBefore.last().round,
                newRounds = 0,
                lastSyncEpochMillis = lastSync
            )
        }

        return load(refresh = true)
    }

    private fun readValidCacheOrNull(): List<LottoDraw>? {
        if (!cacheFile.exists()) return null
        return runCatching {
            val cached = parse(cacheFile.readText())
            validate(cached)
            cached
        }.getOrNull()
    }

    private fun atomicWriteCache(json: String) {
        val temp = File(context.filesDir, "lotto_history.tmp")
        temp.writeText(json)
        if (cacheFile.exists() && !cacheFile.delete()) error("기존 캐시 교체 실패")
        if (!temp.renameTo(cacheFile)) {
            // 일부 파일시스템에서 rename이 실패할 경우 안전하게 복사 후 임시파일 삭제
            cacheFile.writeText(json)
            temp.delete()
        }
    }

    private fun download(url: String): String {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12_000
            readTimeout = 20_000
            setRequestProperty("User-Agent", "LottoProbabilityLab/0.8 Android")
            setRequestProperty("Accept", "application/json")
            useCaches = false
        }
        return try {
            val code = conn.responseCode
            if (code !in 200..299) error("HTTP $code")
            conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun parse(json: String): List<LottoDraw> {
        val arr = JSONArray(json)
        val out = ArrayList<LottoDraw>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val nums = o.getJSONArray("numbers")
            val six = (0 until nums.length()).map { nums.getInt(it) }
            if (six.size != 6) continue
            out += LottoDraw(
                round = o.getInt("draw_no"),
                mainNumbers = six,
                bonus = o.getInt("bonus_no"),
                drawDate = o.optString("date").takeIf { it.isNotBlank() }?.take(10)
            )
        }
        return out.distinctBy { it.round }.sortedBy { it.round }
    }

    private fun validate(draws: List<LottoDraw>) {
        require(draws.size >= 1000) { "수신된 회차 수가 비정상적으로 적습니다: ${draws.size}" }
        require(draws.first().round == 1) { "1회 데이터가 없습니다." }
        draws.forEachIndexed { index, d ->
            require(d.round == index + 1) { "회차 누락/순서 오류: ${d.round}회" }
            require(d.mainNumbers.size == 6 && d.mainNumbers.toSet().size == 6) { "${d.round}회 본번호 오류" }
            require(d.mainNumbers.all { it in 1..45 } && d.bonus in 1..45) { "${d.round}회 번호 범위 오류" }
            require(d.bonus !in d.mainNumbers) { "${d.round}회 보너스 중복 오류" }
        }
    }
}
