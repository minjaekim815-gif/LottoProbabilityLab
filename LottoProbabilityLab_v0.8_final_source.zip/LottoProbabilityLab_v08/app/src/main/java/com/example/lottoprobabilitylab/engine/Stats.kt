package com.example.lottoprobabilitylab.engine

import kotlin.math.exp
import kotlin.math.sqrt

internal fun normalize(values: Map<Int, Double>): Map<Int, Double> {
    if (values.isEmpty()) return values
    val min = values.values.minOrNull() ?: 0.0
    val max = values.values.maxOrNull() ?: 1.0
    if (max - min < 1e-12) return values.mapValues { 0.5 }
    return values.mapValues { (_, v) -> (v - min) / (max - min) }
}

internal fun mean(xs: List<Double>): Double = if (xs.isEmpty()) 0.0 else xs.average()

internal fun sd(xs: List<Double>): Double {
    if (xs.size < 2) return 0.0
    val m = xs.average()
    return sqrt(xs.sumOf { (it - m) * (it - m) } / (xs.size - 1))
}

internal fun gaussianScore(x: Double, center: Double, sigma: Double): Double {
    if (sigma <= 1e-9) return 0.5
    val z = (x - center) / sigma
    return exp(-0.5 * z * z).coerceIn(0.0, 1.0)
}
