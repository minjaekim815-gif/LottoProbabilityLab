# v0.8 APK 빌드 메모

## 권장 환경
- JDK 17
- Android SDK Platform 37
- Android SDK Build Tools 36.0.0
- Gradle 9.3.1
- Android Gradle Plugin 9.1.1

## Debug APK 위치
`app/build/outputs/apk/debug/app-debug.apk`

## 체크 순서
1. `:app:testDebugUnitTest`
2. `:app:assembleDebug`
3. Android 8.0(API 26) 이상 단말 설치 테스트
4. 첫 실행 온라인 전체회차 동기화 확인
5. 네트워크 차단 후 로컬 캐시 재실행 확인
6. 추천/분석/검증/가중치 4개 탭 확인

### v0.8 data sync
LottoRepository now persists the last validated full history in app-internal storage. On launch it checks the online data, compares the last round, atomically updates the cache when needed, and falls back to the last valid cache on network failure. A newly detected round triggers the normal full analysis pipeline again.
